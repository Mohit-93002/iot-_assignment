from flask import Flask, jsonify
import mysql.connector

app = Flask(__name__)

# DB connection function
def get_connection():
    return mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="luke",
        database="employee_info",
        port=3306
    )

# 1 Web Service: Print all employees
@app.route("/employees", methods=["GET"])
def get_all_employees():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM info")
    data = cursor.fetchall()

    cursor.close()
    conn.close()
    return jsonify(data)

# 2 Web Service: Employees of given department
@app.route("/employees/department/<dept>", methods=["GET"])
def get_employees_by_department(dept):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    query = f"SELECT * FROM info WHERE department = '{dept}'"
    cursor.execute(query)
    data = cursor.fetchall()

    cursor.close()
    conn.close()
    return jsonify(data)

# 3 Web Service: Employee with highest salary
@app.route("/employees/highest-salary", methods=["GET"])
def highest_salary_employee():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM info ORDER BY salary DESC LIMIT 1")
    data = cursor.fetchone()

    cursor.close()
    conn.close()
    return jsonify(data)

# 4 Web Service: Employee with lowest salary
@app.route("/employees/lowest-salary", methods=["GET"])
def lowest_salary_employee():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM info ORDER BY salary ASC LIMIT 1")
    data = cursor.fetchone()

    cursor.close()
    conn.close()
    return jsonify(data)

# start server
if __name__ == "__main__":
    app.run(debug=True)
