import mysql.connector

# create database connection
connection = mysql.connector.connect(
    host="127.0.0.1",
    port=3306,
    user="root",
    password="luke",
    database="employee_info",
    use_pure=True
)

cursor = connection.cursor()

while True:
    print("\n--- Employee Server Menu ---")
    print("1. Add Employee")
    print("2. Update Employee")
    print("3. Delete Employee")
    print("4. View Employees")
    print("5. Exit")

    choice = int(input("Enter choice: "))

    # ADD employee
    if choice == 1:
        empid = int(input("Emp ID: "))
        name = input("Name: ")
        dept = input("Department: ")
        email = input("Email: ")
        salary = int(input("Salary: "))
        joining_date = input("Joining Date (DD-MM-YYYY): ")

        query = f"""
        INSERT INTO info
        VALUES ({empid}, '{name}', '{dept}', '{email}', {salary}, '{joining_date}')
        """
        cursor.execute(query)
        connection.commit()
        print("✅ Employee added successfully")

    # UPDATE employee
    elif choice == 2:
        empid = int(input("Emp ID to update: "))
        salary = int(input("New Salary: "))
        dept = input("New Department: ")

        query = f"""
        UPDATE info
        SET salary = {salary}, department = '{dept}'
        WHERE empid = {empid}
        """
        cursor.execute(query)
        connection.commit()
        print("✅ Employee updated successfully")

    # DELETE employee
    elif choice == 3:
        empid = int(input("Emp ID to delete: "))

        query = f"DELETE FROM info WHERE empid = {empid}"
        cursor.execute(query)
        connection.commit()
        print("✅ Employee deleted successfully")

    # VIEW employees
    elif choice == 4:
        cursor.execute("SELECT * FROM info")
        rows = cursor.fetchall()

        print("\nEMPID | NAME | DEPT | EMAIL | SALARY | JOINING DATE")
        for row in rows:
            print(row)

    # EXIT
    elif choice == 5:
        print("Server stopped")
        break

    else:
        print("Invalid choice")

# close resources
cursor.close()
connection.close()
