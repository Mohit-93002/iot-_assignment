from flask import Flask,request
from DB_CRUD_OPS.DB_Connection import getDBConnection
import paho.mqtt.client as mqtt


def on_publish(client, userdata, mid, reason_code, properties):
    print("Message is published")


def publish_message(query,method,url):
    publisher = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    publisher.connect(host="localhost")
    publisher.on_publish = on_publish

    try:
        data =  getDBConnection(query,method)
        status = "success"
    except:
        status = "failure"
    publisher.publish(topic='health/status',payload=f"{request.method} {url}  {status}")
    publisher.disconnect()
    return data

server = Flask(__name__)


@server.post('/add')
def add_user():
    name = request.get_json().get('name')
    age = request.get_json().get('age')
    city = request.get_json().get('city')
    temp = request.get_json().get('temp')
    oxy = request.get_json().get('oxy')
    pulse = request.get_json().get('pulse')
    step = request.get_json().get('step')

    query = f"insert into health_info values('{name}',{age},'{city}',{temp},{oxy},{pulse},{step});"

    return publish_message(query,request.method,request.url)


@server.get('/all')
def all_user():
    query = "select *from health_info;"
    # print(request.url)
    return publish_message(query,request.method,request.url)

@server.get('/info')
def show_user():
    name = request.get_json().get('name')
    query = f"select *from health_info where name = '{name}'"
    return publish_message(query,request.method,request.url)

@server.put('/update')
def update_user():
    name = request.get_json().get('name')
    city = request.get_json().get('city')
    query = f"update health_info set city = '{city}' where name = '{name}'"
    return publish_message(query,request.method,request.url)

@server.get('/steps')
def max_step_user():
    query = "select *from health_info where step = (SELECT MAX(step) from health_info);"
    return publish_message(query,request.method,request.url)

if __name__ == "__main__":
    server.run(debug=True)

