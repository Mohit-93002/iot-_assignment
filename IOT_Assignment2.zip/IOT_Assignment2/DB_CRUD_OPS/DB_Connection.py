import mysql.connector

def getDBConnection(query,method):
    connection = mysql.connector.connect(
        host = "localhost",
        port = 3306,
        user = "root",
        password = "luke",
        database = "fitness"
    )

    cursor = connection.cursor()
    cursor.execute(query)

    if method == "GET":
        data = cursor.fetchall()
    else:
        connection.commit()

    cursor.close()
    connection.close()

    if method == "GET":
        return data
    else:
        return f"{method} is successful"
