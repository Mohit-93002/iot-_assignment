import paho.mqtt.client as mqtt

def on_message(client, userdata, message):
    print(message.payload)

subscriber = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

subscriber.connect(host="localhost")

subscriber.on_message = on_message

subscriber.subscribe(topic='health/status')

subscriber.loop_forever()